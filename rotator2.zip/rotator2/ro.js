var s = [
    "1index.html",
    "http://rainpool.io/r/50196",
    "http://faucethub.io/r/3150161",
    "http://jompi.tk/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://elenafaucets.com/freebitcoin01/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://elenafaucets.com/freebitcoin02/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://elenafaucets.com/freebitcoin03/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://elenafaucets.com/freebitcoin04/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://jackpotfaucet.com/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://ioanbtc.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://fausetbit.ru/fauset5/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://www.btcsoup.us/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.sinkbuddy.club/rainpool/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://xoloniex.info/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://www.btcsoup.us/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoinstraker.com/faucetstriker/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.ref-hunters.ch/btcfaucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://coinforeveryone.pw/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.ref-hunters.ch/btcfaucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://satoshi-progress.xyz/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://btc4clicks.com/ref/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://btc.bitcoinspace.us/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://kran.domfaucet.ru?ref=416",
    "http://faucet.geekhash.org/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://crazysat.ru/craz5/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://kingoffaucet.online/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://t9173848.bget.ru/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://faucet.withbitco.in/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://www.rollthebit.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://satoshilabs.net/?ref=6628",
    "https://topbtcsites.com/freebitcoin/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://www.btcsoup.us/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://faucetboy.xyz/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://yourfreesatoshi.website/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://melovin.site/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://xcoins.rosecoins.net/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bigbtc.win/?id=104269",
    "http://my115.net/?ref=1767",
    "http://btclife.info?ref=599",
    "http://www.gobits.io/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://bitlucky.io/ref/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://satoshilabs.net/?ref=6628",
    "https://bituniverse.net/ref/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://xcoins.rosecoins.net/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoin-kran.wtfd.ru/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://bagi.co.in/bitcoin/?ref=9447",
    "http://freebitcoinbuilder.com/?rid=3403",
    "http://landoffaucets.com/bitcoin-faucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://landoffaucets.com/bitcoin-faucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.maddoglion.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.bitcoinquick.xyz/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitzer.com.es/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://easybit.ml/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://hotcoins.cf/?id=279574",
    "http://www.cryptoprofits.in.ua/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://getfree.co.in/?id=1830040",
    "https://luckybtcfaucet.website/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://satoshimonster.cf/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoinfaucet.online/?id=72764",
    "http://freebit.today/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://faucethub.bitganancias.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://fausetbit.ru/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://coinfaucet.space/index.php?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://satoshis.online/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://btc4free.today/?ref=21356",
    "http://www.maddoglion.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://topbtc.club/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoingala.xyz/reward/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://freebit.today/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.cryptoprofits.in.ua/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://theconomicsofbitcoin.website/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.bitcoinquick.xyz/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://btc4free.site/faucet/?ref=16273",
    "http://bestbtcfaucet.live/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://freebits.us/efaucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://my115.net/?ref=1767",
    "http://hamsab.net/platinum/?ref=1257",
    "http://20hk.com/?ref=2189",
    "http://btcinbtc.com/faucet/?ref=5050",
    "http://bitcoball.com/?ref=1043",
    "http://bitcoingala.xyz/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://huefaucet.xyz/ref/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://brfaucet.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://btclife.info?ref=599",
    "http://bigbtc.win/?id=104269",
    "http://www.oneclickhere.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://landoffaucets.com/bitcoin-faucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://fausetbit.ru/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://cokefaucet.xyz/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoland.net/?ref=12731",
    "https://faucetboy.xyz/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://btcfaucet.design/?ref=3001",
    "http://www.maddoglion.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://fausetdog.ru/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoin-faucet.bitmmgp.ru/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://cryptonic.co/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF ",
    "http://50sat.bitcoinfaucet.online/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://smartbitco.club/?ref=14707",
    "http://rektbitcoins.pw/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://brfaucet.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://xbtfaucet.tk/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://faucet.withbitco.in/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://satoshistorm.club/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://tetrafaucet.top/?ref=679",
    "http://u24.co/en/faucet/ref/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://freebits.us?id=1189",
    "http://bitaler.com/btc/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitpocket.fr/refer/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://faucet.mygolden-bird.ru/?ref=315",
    "https://www.keran.co/bitcoin/?ref=1884",
    "http://yannik.biz/?ref=48936",
    "http://www.apolobitcoin.club/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.nuclearbit.club/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoinstraker.com/faucetstraker/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://bitcoinstraker.com/faucetyi/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://yibtccoins.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://fausetbit.ru/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.taurusfaucet.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://euan.tech/faucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://crazysat.ru/craz5/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://free-faucets.tk/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://distan29.us/Extra/5minute/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://satoshi-club.com/paid.php?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://hamsab.net/diamond/?ref=2318",
    "http://www.helpmywallet.com/faucet/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://freebtcoin.tk/?r=Your_Address",
    "http://btc.bitcoinspace.us/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://btc-faucet.mcdir.ru/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "Reflink: http://free-faucets.tk/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://freebit.today/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "https://btcforclicks.io/ref/3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://faucet.geekhash.org/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://piratesreward.online/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://btcforeveryone.xyz/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://vipfaucet.ga/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://xoloniex.info/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://yourfreesatoshi.website/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.ref-hunters.ch/btcmission/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://alpha.domfaucet.ru/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://vipfaucet.ga/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.oneclickhere.com/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.viralfaucet.com/?ref=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.ref-hunters.ch/btcforever/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://yourfreesatoshi.website/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://vipfaucet.ga/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://www.get-free-btc.com/fh/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
    "http://vipfaucet.ga/?r=3DybgojWAvRWw6W2dkC5Cnj3HhAH9tA1WF",
];
var adr, i, x = 0, c = s.length;
function address() {
    adr = prompt('Enter your bitcoin address:');
    s = s.map(function (x) {
        return x.indexOf("a=") != -1 ? x + adr : x;
    });
}
function next() {
    x += 1;
    if (x > c - 1) {
        x = 0;
    }
    changeSrc();
}
function prev() {
    x -= 1;
    if (x <= 0) {
        x = c - 1;
    }
    changeSrc();
}
function jumpTo() {
    i = prompt("Enter a number to skip to that faucet.");
    x = 0;
    while (i != x) {
        if (x > c - 2) {
            break;
        }
        x += 1;
    }
    changeSrc();
}
function newTab() {
    var win = window.open(document.getElementById("fm").src, '_blank');
    win.focus();
}
function changeSrc() {
    document.getElementById("fm").src = s[x];
}
