# facethub Rotator

This is an open source faucethub rotator i willcontinue to workon this rotator and add faucetsystem an other faucets.
ideas and help wanted to make this the best rotator alive.
please fork and add your ideas.
1. dice game. 
2. ptc wall easy intergration
3. grid wall
4. casino 
This Rotator is simple to install
Instructions:
!download files server using ftp or file manager 
